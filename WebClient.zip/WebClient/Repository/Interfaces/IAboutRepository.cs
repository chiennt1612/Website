﻿using EntityFramework.Web.Entities;

namespace WebClient.Repository.Interfaces
{
    public interface IAboutRepository : IGenericRepository<About, long>
    {
    }
}
