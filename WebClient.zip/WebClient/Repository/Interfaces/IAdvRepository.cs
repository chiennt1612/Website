﻿using EntityFramework.Web.Entities;

namespace WebClient.Repository.Interfaces
{
    public interface IAdvRepository : IGenericRepository<Adv, long>
    {
    }
}
