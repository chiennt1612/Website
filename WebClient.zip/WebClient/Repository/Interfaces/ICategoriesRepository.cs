﻿using EntityFramework.Web.Entities;

namespace WebClient.Repository.Interfaces
{
    public interface ICategoriesRepository : IGenericRepository<Categories, long>
    {
    }
}
