﻿using EntityFramework.Web.Entities;

namespace WebClient.Repository.Interfaces
{
    public interface IMenuSubFooterRepository : IGenericRepository<MenuSubFooter, long>
    {
    }
}
