﻿namespace WebClient.Models.Partial
{
    public class HeaderContact
    {
        public string TimeOpen { get; set; }
        public string Hotline { get; set; }
    }
}
