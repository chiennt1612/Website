﻿using WebClient.Models.Category;

namespace WebClient.Models.Order
{
    public class ViewCart
    {
        public CreateOrder order { get; set; }
        public ProductView product { get; set; }
    }
}
